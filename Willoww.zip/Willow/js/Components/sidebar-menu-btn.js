
    // $('.sidebar__login-btn').on('click', function(e){
    //     e.preventDefault();
    //     $('.login-page__box').toggleClass('active');
    //     $('.sidebar').toggleClass('active');
    //     $('.login-page__box-title').toggleClass('active');
    // });
    // $('.login-page__box-title').on('click', function(e){
    //     e.preventDefault();
    //     $('.login-page__box').removeClass('active');
    //     $('.sidebar').removeClass('active');
    //     $('.login-page__box-title').removeClass('active');
    // });
